﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'tt', {
	copy: 'Copyright &copy; $1. Бар хокуклар сакланган',
	dlgTitle: 'CKEditor турында',
	help: 'Ярдәм өчен $1 тикшереп карагыз.',
	moreInfo: 'For licensing information please visit our web site:', // MISSING
	title: 'CKEditor турында',
	userGuide: 'CKEditor кулланмасы'
} );
