﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'hi', {
	block: 'ब्लॉक जस्टीफ़ाई',
	center: 'बीच में',
	left: 'बायीं तरफ',
	right: 'दायीं तरफ'
} );
