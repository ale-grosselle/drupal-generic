﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'km', {
	block: 'តម្រឹម​ពេញ',
	center: 'កណ្ដាល',
	left: 'តម្រឹម​ឆ្វេង',
	right: 'តម្រឹម​ស្ដាំ'
} );
